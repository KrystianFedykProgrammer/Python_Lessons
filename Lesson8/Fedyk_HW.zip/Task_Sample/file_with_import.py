from Task_Sample.file_with_function import square_number


def import_file():
    a = square_number()
    return a



