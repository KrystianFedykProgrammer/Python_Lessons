print('Hello, its init file', end='\n\n')
