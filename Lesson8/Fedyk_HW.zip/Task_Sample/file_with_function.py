
def square_number():
    num = {i: i ** 2 for i in range(1, 11)}
    return num







